package com.siroa.soda

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import java.nio.ByteBuffer

class CaptureService:Service() {
 private var projection:MediaProjection?=null
 private var reader:ImageReader?=null
 private var display:android.hardware.display.VirtualDisplay?=null
 private var wm:WindowManager?=null
 private var overlay:TextView?=null
 private val handler=Handler(Looper.getMainLooper())
 private var running=false
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
  if(running)return START_NOT_STICKY
  val channel="soda_capture"
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel,"화면 분석",NotificationManager.IMPORTANCE_LOW))
  val notification=Notification.Builder(this,channel).setContentTitle("Soda Helper 분석 중").setContentText("게임 화면을 분석합니다").setSmallIcon(android.R.drawable.ic_menu_search).build()
  startForeground(1,notification)
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  overlay=TextView(this).apply { text="Soda Helper: 분석 준비";textSize=16f;setTextColor(Color.WHITE);setBackgroundColor(0xCC263238.toInt());setPadding(16,12,16,12) }
  wm!!.addView(overlay,WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply {gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;y=90})
  val code=intent?.getIntExtra("resultCode",Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED
  @Suppress("DEPRECATION") val data=if(Build.VERSION.SDK_INT>=33)intent?.getParcelableExtra("data",Intent::class.java) else intent?.getParcelableExtra<Intent>("data")
  if(data==null){stopSelf();return START_NOT_STICKY}
  val manager=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=manager.getMediaProjection(code,data)
  projection!!.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},handler)
  val metrics=resources.displayMetrics;val w=metrics.widthPixels;val h=metrics.heightPixels
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
  display=projection!!.createVirtualDisplay("SodaHelper",w,h,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
  running=true
  handler.postDelayed(object:Runnable {override fun run(){if(!running)return;analyze();handler.postDelayed(this,1500)}},1800)
  return START_NOT_STICKY
 }
 private fun analyze(){
  val image=reader?.acquireLatestImage()?:return
  try {
   val plane=image.planes[0];val buffer=plane.buffer
   val width=image.width;val height=image.height
   val bmp=Bitmap.createBitmap(width+ (plane.rowStride-plane.pixelStride*width)/plane.pixelStride,height,Bitmap.Config.ARGB_8888)
   bmp.copyPixelsFromBuffer(buffer)
   // Calibrated against a 709x1536 portrait gameplay screenshot.
   // Grid is approximately x=18..690, y=432..1105 in that capture.
   // Not a general-purpose detector: uncertain cells must remain blocked.
   val cell=width*0.105f
   val left=width*0.025f
   val top=height*0.281f
   val board=Array(9){IntArray(9){-1}}
   for(r in 0..8)for(c in 0..8){
    val cx=left+(c+0.5f)*cell
    val cy=top+(r+0.5f)*cell
    val votes=IntArray(5)
    val offsets=listOf(0f to 0f, -0.09f to 0f, 0.09f to 0f, 0f to -0.09f, 0f to 0.09f)
    for((dx,dy) in offsets){
     val x=(cx+dx*cell).toInt();val y=(cy+dy*cell).toInt()
     if(x !in 0 until width||y !in 0 until height)continue
     val p=bmp.getPixel(x,y)
     val hsv=FloatArray(3);Color.colorToHSV(p,hsv)
     val hue=hsv[0];val sat=hsv[1];val value=hsv[2]
     val kind=when {
      sat<0.52f||value<0.40f -> -1
      hue<18f||hue>=348f -> 0 // red
      hue in 82f..158f -> 1 // green
      hue in 178f..215f && value>0.68f -> 2 // cyan
      hue in 36f..66f -> 3 // yellow
      hue in 18f..36f -> 4 // orange
      else -> -1
     }
     if(kind>=0)votes[kind]++
    }
    val winner=votes.indices.maxByOrNull{votes[it]}?:-1
    if(winner>=0&&votes[winner]>=4)board[r][c]=winner
   }
   val move=MoveSolver.best(board)
   overlay?.text=if(move==null)"Soda Helper: 확실한 추천 없음 (인식 불확실)" else "추천: ${move.row+1}행 ${move.col+1}열 → ${move.toRow+1}행 ${move.toCol+1}열 · ${move.score}칸 (시험)"
   bmp.recycle()
  }catch(e:Exception){overlay?.text="분석 오류: ${e.javaClass.simpleName}"}finally{image.close()}
 }
 override fun onDestroy(){running=false;display?.release();reader?.close();projection?.stop();overlay?.let{wm?.removeView(it)};super.onDestroy()}
}
