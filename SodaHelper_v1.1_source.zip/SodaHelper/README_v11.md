# Soda Helper v1.1

- HSV 9x9 region sampling per cell, center highlight excluded.
- Candy voting, tile/obstacle candidate diagnostics.
- No move recommendation until validated against live game.
- Manual grid calibration remains; no universal board detection yet.
- APK build and device behavior not yet verified.
