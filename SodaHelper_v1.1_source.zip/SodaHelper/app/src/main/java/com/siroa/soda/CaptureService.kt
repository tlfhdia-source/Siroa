package com.siroa.soda

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import kotlin.math.*

class CaptureService : Service() {
 private var projection: MediaProjection? = null
 private var reader: ImageReader? = null
 private var display: android.hardware.display.VirtualDisplay? = null
 private var wm: WindowManager? = null
 private var overlay: TextView? = null
 private var gridOverlay: GridOverlay? = null
 private val handler = Handler(Looper.getMainLooper())
 private var running = false
 private var lastBoard = ""
 private var stableFrames = 0
 override fun onBind(intent: Intent?) = null
 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
  if (running) return START_NOT_STICKY
  val channel = "soda_capture"
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel, "화면 분석", NotificationManager.IMPORTANCE_LOW))
  startForeground(1, Notification.Builder(this, channel).setContentTitle("Soda Helper 진단 중").setContentText("캔디 인식 확인 중").setSmallIcon(android.R.drawable.ic_menu_search).build())
  wm = getSystemService(WINDOW_SERVICE) as WindowManager
  overlay = TextView(this).apply {
   text = "Soda Helper v1.1 · 보수적 분석"; textSize = 13f
   setTextColor(Color.WHITE); setBackgroundColor(0xDD18232B.toInt()); setPadding(12, 8, 12, 8)
  }
  wm!!.addView(overlay, WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP; y = 45 })
  gridOverlay = GridOverlay(this)
  wm!!.addView(gridOverlay, WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP })
  val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
  @Suppress("DEPRECATION") val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra<Intent>("data")
  if (data == null) { stopSelf(); return START_NOT_STICKY }
  val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection = manager.getMediaProjection(code, data)
  projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
  val metrics = resources.displayMetrics
  reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
  display = projection!!.createVirtualDisplay("SodaHelper", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
  running = true
  handler.postDelayed(object : Runnable { override fun run() { if (!running) return; analyze(); handler.postDelayed(this, 1800) } }, 2000)
  return START_NOT_STICKY
 }
 // HSV classification is evaluated over a candy-shaped region, not a single bright pixel.
 private fun colorClass(pixel: Int): Int {
  val hsv = FloatArray(3); Color.colorToHSV(pixel, hsv)
  val h=hsv[0]; val sat=hsv[1]; val v=hsv[2]
  if (sat < .40f || v < .30f) return -1
  return when {
   h < 14f || h >= 347f -> 0
   h in 74f..165f -> 1
   h in 174f..225f -> 2
   h in 41f..73f -> 3
   h in 14f..40f -> 4
   else -> -1
  }
 }
 private fun analyze() {
  val image = reader?.acquireLatestImage() ?: return
  var bmp: Bitmap? = null
  try {
   val plane = image.planes[0]
   val strideWidth = image.width + (plane.rowStride - plane.pixelStride * image.width) / plane.pixelStride
   bmp = Bitmap.createBitmap(strideWidth, image.height, Bitmap.Config.ARGB_8888)
   bmp.copyPixelsFromBuffer(plane.buffer)
   val width = image.width; val height = image.height
   // v0.5: Every frame gets a fresh occupancy classification. No hard-coded holes.
   // Grid geometry is still an approximate 9x9 reference calibration; it is NOT
   // a universal board detector. Do not recommend moves until geometry is verified.
   val sx = width / 709f; val sy = height / 1536f
   val labels = charArrayOf('R', 'G', 'B', 'Y', 'O')
   val prefs = getSharedPreferences("grid", MODE_PRIVATE)
   val rows = prefs.getInt("rows", 9).coerceIn(3, 15)
   val cols = prefs.getInt("cols", 9).coerceIn(3, 15)
   val left = prefs.getFloat("left", 0.022f).coerceIn(0f, .95f)
   val top = prefs.getFloat("top", .253f).coerceIn(0f, .95f)
   val right = prefs.getFloat("right", .978f).coerceIn(left + .01f, 1f)
   val bottom = prefs.getFloat("bottom", .708f).coerceIn(top + .01f, 1f)
   // Overlay is for visual calibration only; does not imply cell validity.
   gridOverlay?.update(rows, cols, left, top, right, bottom)
   val board = Array(rows) { CharArray(cols) { '?' } }
   var candyCount = 0; var emptyCount = 0; var blockedCount = 0
   for (r in 0 until rows) for (c in 0 until cols) {
    val cellW = (right-left)*width/cols
    val cellH = (bottom-top)*height/rows
    val cx = (left*width + (c+.5f)*cellW)
    val cy = (top*height + (r+.5f)*cellH)
    val votes = IntArray(5)
    var dark = 0; var blueTile = 0; var samples = 0; var saturated = 0
    // Sample the candy body over 9x9 points, excluding the central specular highlight.
    // Normalized offsets work with different cell sizes and calibrated board bounds.
    val offsets = floatArrayOf(-.29f,-.22f,-.15f,-.08f,0f,.08f,.15f,.22f,.29f)
    for (oy in offsets) for (ox in offsets) {
     if (abs(ox) < .09f && abs(oy) < .09f) continue
     val x = (cx + ox*cellW).roundToInt()
     val y = (cy + oy*cellH).roundToInt()
     if (x !in 0 until width || y !in 0 until height) continue
     val pixel = bmp.getPixel(x,y); samples++
     val hsv = FloatArray(3); Color.colorToHSV(pixel,hsv)
     if (hsv[2] < .25f) dark++
     if (hsv[0] in 192f..238f && hsv[1] > .32f && hsv[2] in .17f.. .72f) blueTile++
     if (hsv[1] > .45f && hsv[2] > .38f) saturated++
     val type = colorClass(pixel)
     if (type >= 0) votes[type]++
    }
    val winner = votes.indices.maxByOrNull { votes[it] } ?: 0
    val ranked = votes.sortedDescending()
    // Do not call a candy when samples disagree or the tile dominates.
    val label = when {
     samples < 55 -> '?'
     votes[winner] >= 25 && votes[winner] >= (samples * .39f).toInt() && ranked[0]-ranked[1] >= 12 -> labels[winner]
     dark >= (samples * .55f).toInt() -> '#'
     blueTile >= (samples * .65f).toInt() && saturated < (samples * .35f).toInt() -> '.'
     else -> '?'
    }
    board[r][c] = label
    when(label) {
     in labels -> candyCount++
     '.' -> emptyCount++
     '#' -> blockedCount++
    }
   }
   val lines = board.joinToString("/") { String(it) }
   stableFrames = if (lines == lastBoard) stableFrames + 1 else 0
   lastBoard = lines
   // Unknown, blocked and obstacle cells are NEVER treated as swappable candies.
   // The geometry is still approximate, so the solver is used only for diagnostics.
   val verifiedBoard = BoardEngine.Board(board.map { row -> row.map { ch ->
    when (ch) {
     'R','G','B','Y','O' -> BoardEngine.Cell(BoardEngine.Kind.CANDY,
       "RGBYO".indexOf(ch), 0.70, true)
     '#' -> BoardEngine.Cell(BoardEngine.Kind.OBSTACLE)
     '.' -> BoardEngine.Cell(BoardEngine.Kind.BLOCKED)
     else -> BoardEngine.Cell(BoardEngine.Kind.UNKNOWN)
    }
   } })
   val evaluation = BoardEngine.evaluate(verifiedBoard)
   val solverStatus = if (stableFrames < 2) "화면 변화 중: 판단 보류"
     else "판단 보류: ${evaluation.reason ?: "좌표/색상 미검증"}"

   // Diagnostic-only: a visually classified cell is NOT proof of a correct game move.
   overlay?.text = "Soda Helper v1.1 | ${rows}x${cols} | 캔디 $candyCount | 막힌칸 후보 $emptyCount | 장애물 후보 $blockedCount | 미확인 ${rows*cols-candyCount-emptyCount-blockedCount}\n추천 중지 · HSV 다중 샘플 진단"
  } catch (e: Exception) { overlay?.text = "진단 오류: ${e.javaClass.simpleName}" }
  finally { bmp?.recycle(); image.close() }
 }
 override fun onDestroy() { running = false; display?.release(); reader?.close(); projection?.stop(); overlay?.let { wm?.removeView(it) }; gridOverlay?.let { wm?.removeView(it) }; super.onDestroy() }
}
