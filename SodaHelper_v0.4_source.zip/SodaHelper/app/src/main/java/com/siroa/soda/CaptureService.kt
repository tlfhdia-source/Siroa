package com.siroa.soda

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import kotlin.math.*

class CaptureService : Service() {
 private var projection: MediaProjection? = null
 private var reader: ImageReader? = null
 private var display: android.hardware.display.VirtualDisplay? = null
 private var wm: WindowManager? = null
 private var overlay: TextView? = null
 private val handler = Handler(Looper.getMainLooper())
 private var running = false
 override fun onBind(intent: Intent?) = null
 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
  if (running) return START_NOT_STICKY
  val channel = "soda_capture"
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel, "화면 분석", NotificationManager.IMPORTANCE_LOW))
  startForeground(1, Notification.Builder(this, channel).setContentTitle("Soda Helper 진단 중").setContentText("캔디 인식 확인 중").setSmallIcon(android.R.drawable.ic_menu_search).build())
  wm = getSystemService(WINDOW_SERVICE) as WindowManager
  overlay = TextView(this).apply {
   text = "Soda Helper v0.4 · 진단 준비"; textSize = 13f
   setTextColor(Color.WHITE); setBackgroundColor(0xDD18232B.toInt()); setPadding(12, 8, 12, 8)
  }
  wm!!.addView(overlay, WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP; y = 45 })
  val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
  @Suppress("DEPRECATION") val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra<Intent>("data")
  if (data == null) { stopSelf(); return START_NOT_STICKY }
  val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection = manager.getMediaProjection(code, data)
  projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
  val metrics = resources.displayMetrics
  reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
  display = projection!!.createVirtualDisplay("SodaHelper", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
  running = true
  handler.postDelayed(object : Runnable { override fun run() { if (!running) return; analyze(); handler.postDelayed(this, 1800) } }, 2000)
  return START_NOT_STICKY
 }
 private fun colorClass(pixel: Int): Int {
  val hsv = FloatArray(3); Color.colorToHSV(pixel, hsv)
  val h = hsv[0]; val s = hsv[1]; val v = hsv[2]
  if (s < .44f || v < .34f) return -1
  return when {
   h < 14f || h >= 350f -> 0 // red
   h in 78f..162f -> 1 // green
   h in 178f..218f -> 2 // blue
   h in 40f..68f -> 3 // yellow
   h in 15f..39f -> 4 // orange
   else -> -1
  }
 }
 private fun analyze() {
  val image = reader?.acquireLatestImage() ?: return
  var bmp: Bitmap? = null
  try {
   val plane = image.planes[0]
   val strideWidth = image.width + (plane.rowStride - plane.pixelStride * image.width) / plane.pixelStride
   bmp = Bitmap.createBitmap(strideWidth, image.height, Bitmap.Config.ARGB_8888)
   bmp.copyPixelsFromBuffer(plane.buffer)
   val width = image.width; val height = image.height
   // Calibrated to the supplied 709x1536 screenshot. Not universal.
   val sx = width / 709f; val sy = height / 1536f
   val board = Array(9) { IntArray(9) { -1 } }
   val labels = charArrayOf('R', 'G', 'B', 'Y', 'O')
   var count = 0
   for (r in 0..8) for (c in 0..8) {
    // Known holes and licorice blockers in the reference board: never treat them as candies.
    if ((r == 2 && (c == 2 || c == 6)) || (r == 4 && (c == 0 || c == 8)) ||
        (r == 5 && (c == 0 || c == 8)) || (r == 6 && (c == 0 || c == 2 || c == 6 || c == 8)) ||
        (r == 7 && (c == 0 || c == 1)) || (r == 8 && (c == 0 || c == 1 || c == 2 || c == 4 || c == 8))) continue
    val cx = (54 + 75 * c) * sx; val cy = (468 + 75 * r) * sy
    val votes = IntArray(5)
    // Sample a compact area of the candy body; avoid edge/background and bright central highlights.
    for (dy in intArrayOf(-17, -11, 11, 17)) for (dx in intArrayOf(-17, -11, 11, 17)) {
     val x = (cx + dx * sx).roundToInt(); val y = (cy + dy * sy).roundToInt()
     if (x !in 0 until width || y !in 0 until height) continue
     val type = colorClass(bmp.getPixel(x, y))
     if (type >= 0) votes[type]++
    }
    val winner = votes.indices.maxByOrNull { votes[it] } ?: continue
    val sorted = votes.sortedDescending()
    if (votes[winner] >= 9 && sorted[0] - sorted[1] >= 5) { board[r][c] = winner; count++ }
   }
   val lines = board.joinToString("/") { row -> row.joinToString("") { v -> if (v >= 0) labels[v].toString() else "?" } }
   // Diagnostic-only: a visually classified cell is NOT proof of a correct game move.
   overlay?.text = "Soda Helper v0.4 · 분류 $count/81 · 추천 중지 (진단)\n$lines"
  } catch (e: Exception) { overlay?.text = "진단 오류: ${e.javaClass.simpleName}" }
  finally { bmp?.recycle(); image.close() }
 }
 override fun onDestroy() { running = false; display?.release(); reader?.close(); projection?.stop(); overlay?.let { wm?.removeView(it) }; super.onDestroy() }
}
