# Soda Helper v0.1 (Android prototype)

Android Studio에서 폴더를 열고 Gradle Sync 후 앱을 빌드하세요. Android 8+ 필요.

## 사용
1. 앱 실행 → 플로팅 창 권한 허용.
2. 화면 분석 시작 → Android 화면 공유 동의.
3. Candy Crush Soda Saga로 전환.
4. 상단 오버레이에 9×9 격자 기준 추천 좌표가 표시됩니다.
5. 앱으로 돌아와 분석 종료.

## 현재 한계 (중요)
- APK는 포함되지 않은 **소스 프로젝트**이며 실제 기기에서 빌드/검증하지 않았습니다.
- 9×9 정사각 게임판이 화면 중앙에 있다고 가정합니다. 실제 게임판 크기/위치가 다르면 결과가 틀립니다.
- 단일 픽셀의 RGB 기준 단순 분류이므로 실제 게임의 반짝임, 애니메이션, 특수 캔디, 장애물, 소다 레벨 규칙 등을 인식하지 못합니다.
- 이동 점수는 단순 3매치 이상 개수만 계산합니다. 게임 규칙 전체를 반영하지 않습니다.
- Android 버전 및 제조사별 화면 캡처 정책에 따라 동작이 다를 수 있습니다.
- 게임 조작 자동화, 데이터 전송, 접근성 서비스 사용 없음.

## 다음 단계
사용자 화면에 맞춘 게임판 영역 선택, 실제 캔디 템플릿 인식, 특수 캔디 규칙, 시각적 화살표 표시, 테스트 및 APK 빌드.


v0.5 experimental diagnostics: removes fixed blocker/hole coordinates; samples each frame to label likely candy, empty blue tile, dark obstacle, or unknown. Geometry remains a reference 9x9 grid, not an automatic detector. No move suggestions. Verify on device.
