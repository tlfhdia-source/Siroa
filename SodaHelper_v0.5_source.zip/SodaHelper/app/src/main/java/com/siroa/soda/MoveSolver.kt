package com.siroa.soda

object MoveSolver {
 data class Move(val row:Int,val col:Int,val toRow:Int,val toCol:Int,val score:Int)
 fun best(board:Array<IntArray>):Move? {
  val h=board.size;if(h==0)return null;val w=board[0].size
  var best:Move?=null
  fun matches(b:Array<IntArray>):Set<Pair<Int,Int>> {
   val out=mutableSetOf<Pair<Int,Int>>()
   for(r in 0 until h){var c=0;while(c<w){val v=b[r][c];var end=c+1;while(end<w&&v>=0&&b[r][end]==v)end++;if(v>=0&&end-c>=3)for(x in c until end)out.add(r to x);c=end}}
   for(c in 0 until w){var r=0;while(r<h){val v=b[r][c];var end=r+1;while(end<h&&v>=0&&b[end][c]==v)end++;if(v>=0&&end-r>=3)for(y in r until end)out.add(y to c);r=end}}
   return out
  }
  val before=matches(board)
  for(r in 0 until h)for(c in 0 until w)for((dr,dc) in listOf(0 to 1,1 to 0)){
   val nr=r+dr;val nc=c+dc
   if(nr>=h||nc>=w||board[r][c]<0||board[nr][nc]<0||board[r][c]==board[nr][nc])continue
   val b=Array(h){board[it].clone()};b[r][c]=board[nr][nc];b[nr][nc]=board[r][c]
   val newMatches=matches(b)-before
   if(newMatches.size<3||!newMatches.contains(r to c)&&!newMatches.contains(nr to nc))continue
   if(best==null||newMatches.size>best.score)best=Move(r,c,nr,nc,newMatches.size)
  }
  return best
 }
}
