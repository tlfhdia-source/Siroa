package com.siroa.soda

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Non-interactive calibration markers. Grid does not classify or validate cells. */
class GridOverlay(context: Context): View(context) {
 private var rows=9; private var cols=9
 private var left=.022f; private var top=.279f; private var right=.978f; private var bottom=.720f
 private val linePaint=Paint(3).apply { color=Color.argb(135,255,240,70); style=Paint.Style.STROKE; strokeWidth=1.5f }
 private val dotPaint=Paint(3).apply { color=Color.argb(225,255,55,185); style=Paint.Style.FILL }
 fun update(r:Int,c:Int,l:Float,t:Float,rr:Float,b:Float) {
  if(rows==r && cols==c && left==l && top==t && right==rr && bottom==b) return
  rows=r; cols=c; left=l; top=t; right=rr; bottom=b; postInvalidate()
 }
 override fun onDraw(canvas:Canvas) {
  super.onDraw(canvas)
  val x0=left*width; val x1=right*width; val y0=top*height; val y1=bottom*height
  val cw=(x1-x0)/cols; val ch=(y1-y0)/rows
  for(c in 0..cols) { val x=x0+c*cw; canvas.drawLine(x,y0,x,y1,linePaint) }
  for(r in 0..rows) { val y=y0+r*ch; canvas.drawLine(x0,y,x1,y,linePaint) }
  for(r in 0 until rows) for(c in 0 until cols) canvas.drawCircle(x0+(c+.5f)*cw,y0+(r+.5f)*ch,3.5f,dotPaint)
 }
}
