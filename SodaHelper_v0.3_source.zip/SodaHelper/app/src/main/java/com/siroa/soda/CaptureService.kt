package com.siroa.soda

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import java.nio.ByteBuffer

class CaptureService:Service() {
 private var projection:MediaProjection?=null
 private var reader:ImageReader?=null
 private var display:android.hardware.display.VirtualDisplay?=null
 private var wm:WindowManager?=null
 private var overlay:TextView?=null
 private val handler=Handler(Looper.getMainLooper())
 private var running=false
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
  if(running)return START_NOT_STICKY
  val channel="soda_capture"
  (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channel,"화면 분석",NotificationManager.IMPORTANCE_LOW))
  val notification=Notification.Builder(this,channel).setContentTitle("Soda Helper 분석 중").setContentText("게임 화면을 분석합니다").setSmallIcon(android.R.drawable.ic_menu_search).build()
  startForeground(1,notification)
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  overlay=TextView(this).apply { text="Soda Helper: 분석 준비";textSize=16f;setTextColor(Color.WHITE);setBackgroundColor(0xCC263238.toInt());setPadding(16,12,16,12) }
  wm!!.addView(overlay,WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply {gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;y=90})
  val code=intent?.getIntExtra("resultCode",Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED
  @Suppress("DEPRECATION") val data=if(Build.VERSION.SDK_INT>=33)intent?.getParcelableExtra("data",Intent::class.java) else intent?.getParcelableExtra<Intent>("data")
  if(data==null){stopSelf();return START_NOT_STICKY}
  val manager=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=manager.getMediaProjection(code,data)
  projection!!.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},handler)
  val metrics=resources.displayMetrics;val w=metrics.widthPixels;val h=metrics.heightPixels
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
  display=projection!!.createVirtualDisplay("SodaHelper",w,h,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
  running=true
  handler.postDelayed(object:Runnable {override fun run(){if(!running)return;analyze();handler.postDelayed(this,1500)}},1800)
  return START_NOT_STICKY
 }
 private fun analyze(){
  val image=reader?.acquireLatestImage()?:return
  try {
   val plane=image.planes[0];val buffer=plane.buffer
   val width=image.width;val height=image.height
   val bmp=Bitmap.createBitmap(width+ (plane.rowStride-plane.pixelStride*width)/plane.pixelStride,height,Bitmap.Config.ARGB_8888)
   bmp.copyPixelsFromBuffer(buffer)
   // Calibrated against a 709x1536 portrait gameplay screenshot.
   // Grid is approximately x=18..690, y=432..1105 in that capture.
   // Not a general-purpose detector: uncertain cells must remain blocked.
   val cell=width*0.105f
   val left=width*0.025f
   val top=height*0.281f
   // v0.3: conservative classification. Candy highlights are frequently white,
   // so read the coloured body at several off-centre locations instead.
   val board=Array(9){IntArray(9){-1}}
   var recognized=0
   val offsets=listOf(-0.24f to 0f, 0.24f to 0f, 0f to -0.24f, 0f to 0.24f,
      -0.17f to -0.17f, 0.17f to -0.17f, -0.17f to 0.17f, 0.17f to 0.17f)
   for(r in 0..8)for(c in 0..8){
    val cx=left+(c+0.5f)*cell; val cy=top+(r+0.5f)*cell
    val votes=IntArray(5)
    for((dx,dy) in offsets){
     val x=(cx+dx*cell).toInt();val y=(cy+dy*cell).toInt()
     if(x !in 0 until width||y !in 0 until height)continue
     val hsv=FloatArray(3);Color.colorToHSV(bmp.getPixel(x,y),hsv)
     val hue=hsv[0];val sat=hsv[1];val value=hsv[2]
     val kind=when {
      sat<0.62f||value<0.38f -> -1
      hue<15f||hue>=350f -> 0
      hue in 86f..155f -> 1
      hue in 180f..212f -> 2
      hue in 42f..65f -> 3
      hue in 16f..39f -> 4
      else -> -1
     }
     if(kind>=0)votes[kind]++
    }
    val winner=votes.indices.maxByOrNull{votes[it]}?:-1
    // At least 7 of 8 agree: unknown is safer than a false move.
    if(winner>=0&&votes[winner]>=7){board[r][c]=winner;recognized++}
   }
   // This is not yet a verified full-board recognizer. Show diagnostics only;
   // do not claim a valid move from incomplete / unverified recognition.
   val rows=board.joinToString("/"){ row -> row.joinToString(""){v->
     when(v){0->"R";1->"G";2->"B";3->"Y";4->"O";else->"?"}
   }}
   overlay?.text="Soda Helper v0.3 · 인식 ${recognized}/81 · 추천 보류 (검증 필요)\n$rows"
   bmp.recycle()
  }catch(e:Exception){overlay?.text="분석 오류: ${e.javaClass.simpleName}"}finally{image.close()}
 }
 override fun onDestroy(){running=false;display?.release();reader?.close();projection?.stop();overlay?.let{wm?.removeView(it)};super.onDestroy()}
}
