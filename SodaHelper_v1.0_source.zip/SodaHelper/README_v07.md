# Soda Helper v0.7

- v0.6 BoardEngine integrated into MediaProjection capture diagnostics.
- Unknown / blocked / obstacle cells are not swappable.
- Stable-frame gate: requires three identical sampled boards before considering analysis stable.
- No recommendations are displayed because 9x9 calibration and visual confidence are not verified.
- This is NOT a universal board recognizer.
- Android build has not been verified in this environment.
