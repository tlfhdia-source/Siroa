# Soda Helper v0.6 — validated move engine (experimental)

This version adds `BoardEngine.kt`, a pure Kotlin engine independent of Android.
It accepts any rectangular board size and explicitly models CANDY, BLOCKED,
OBSTACLE, UNKNOWN and SPECIAL. It tests horizontal/vertical matches and 2x2 fish
patterns after adjacent swaps, excluding pre-existing patterns. It declines to
recommend when the board contains unknown or special cells, and it never swaps
blocked or obstacle cells. Candidate scores are simple heuristics, not level goals.

IMPORTANT: CaptureService is still the v0.5 diagnostic-only, fixed 9x9 image
classifier. The new engine is NOT connected to that classifier. Therefore the
app cannot yet detect arbitrary boards or safely make live move recommendations.
The engine requires accurate, verified cell state and cannot independently
infer it from screenshots. This is intentional to prevent false recommendations.

To run pure engine tests on a machine with Kotlin installed:
`kotlinc app/src/main/java/com/siroa/soda/BoardEngine.kt ENGINE_TESTS.kt -include-runtime -d tests.jar && java -jar tests.jar`

Next work: calibrated board geometry; per-cell semantic vision classifier;
frame stability check; special-candy and level-goal rules; integration tests
using labeled real gameplay frames. No automatic input is performed.
