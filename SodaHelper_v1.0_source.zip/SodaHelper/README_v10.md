Soda Helper v1.0 coordinate calibration test
- Adjust default vertical bounds from .279-.720 to .253-.708 based on user screenshot.
- Add reset button because previous saved preferences override defaults.
- Grid is diagnostic only, not auto detection; recommendations remain disabled.
- After reset, restart screen capture and compare dots with candy centers.
