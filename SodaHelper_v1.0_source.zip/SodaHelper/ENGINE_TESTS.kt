import com.siroa.soda.BoardEngine
import com.siroa.soda.BoardEngine.Board
import com.siroa.soda.BoardEngine.Cell
import com.siroa.soda.BoardEngine.Kind
import com.siroa.soda.BoardEngine.evaluate
fun b(vararg lines:String):Board=Board(lines.map { line->line.map { ch ->
    when(ch) {
        '#'->Cell(Kind.BLOCKED)
        '?'->Cell(Kind.UNKNOWN)
        'S'->Cell(Kind.SPECIAL)
        else->Cell(Kind.CANDY,ch.code,1.0,true)
    }
} })
fun main() {
    val valid=evaluate(b("ABA","BAC","DBE"))
    check(valid.moves.isNotEmpty()) { "Should detect horizontal/vertical swap" }
    check(evaluate(b("A#A","BBB","CCC")).moves.none { it.fromRow==0 && it.toRow==0 && it.toCol==1 })
    check(evaluate(b("A?A","BBB","CCC")).moves.isEmpty())
    check(evaluate(b("ASA","BBB","CCC")).moves.isEmpty())
    check(evaluate(b("AB","BA")).moves.isEmpty())
    check(evaluate(b("ABC","DEF","GHI")).moves.isEmpty())
    println("PASS: move, blocked, unknown, special, small board, no-match")
}
