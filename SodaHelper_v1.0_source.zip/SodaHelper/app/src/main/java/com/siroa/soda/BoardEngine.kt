package com.siroa.soda

/** Pure, Android-independent move validation engine.
 * The caller must supply a VERIFIED board; this class does not recognize images.
 */
object BoardEngine {
    enum class Kind { CANDY, BLOCKED, OBSTACLE, UNKNOWN, SPECIAL }
    data class Cell(val kind: Kind, val color: Int = -1, val confidence: Double = 0.0,
                    val movable: Boolean = false)
    data class Board(val rows: List<List<Cell>>) {
        val height get() = rows.size
        val width get() = rows.firstOrNull()?.size ?: 0
        init { require(rows.isNotEmpty() && width > 0 && rows.all { it.size == width }) }
        operator fun get(r: Int, c: Int) = rows[r][c]
    }
    data class Move(val fromRow: Int, val fromCol: Int, val toRow: Int, val toCol: Int,
                    val cleared: Int, val makesFish: Boolean, val score: Int)
    data class Result(val moves: List<Move>, val reason: String?)
    private fun matchCells(b: Board): Set<Pair<Int, Int>> {
        val hit = mutableSetOf<Pair<Int, Int>>()
        fun color(r: Int, c: Int): Int = b[r,c].takeIf { it.kind == Kind.CANDY }?.color ?: -1
        for (r in 0 until b.height) {
            var c=0
            while(c<b.width) {
                val v=color(r,c); var end=c+1
                while(v>=0 && end<b.width && color(r,end)==v) end++
                if(v>=0 && end-c>=3) for(x in c until end) hit.add(r to x)
                c=end
            }
        }
        for(c in 0 until b.width) {
            var r=0
            while(r<b.height) {
                val v=color(r,c); var end=r+1
                while(v>=0 && end<b.height && color(end,c)==v) end++
                if(v>=0 && end-r>=3) for(y in r until end) hit.add(y to c)
                r=end
            }
        }
        return hit
    }
    private fun fishSquares(b: Board): Set<Pair<Int, Int>> {
        val hit=mutableSetOf<Pair<Int, Int>>()
        for(r in 0 until b.height-1) for(c in 0 until b.width-1) {
            val cells=listOf(r to c,r to c+1,r+1 to c,r+1 to c+1)
            val v=b[r,c]
            if(v.kind==Kind.CANDY && v.color>=0 && cells.all { (y,x)->b[y,x].kind==Kind.CANDY && b[y,x].color==v.color }) hit.addAll(cells)
        }
        return hit
    }
    fun evaluate(board: Board, minimumConfidence: Double = 0.85): Result {
        if(board.rows.flatten().any { it.kind==Kind.UNKNOWN }) return Result(emptyList(),"미확인 칸 존재: 추천 보류")
        if(board.rows.flatten().any { it.kind==Kind.SPECIAL }) return Result(emptyList(),"특수 캔디 규칙 미검증: 추천 보류")
        val before=matchCells(board); val fishBefore=fishSquares(board)
        val out=mutableListOf<Move>()
        for(r in 0 until board.height) for(c in 0 until board.width) {
            for((dr,dc) in listOf(0 to 1,1 to 0)) {
                val nr=r+dr; val nc=c+dc
                if(nr>=board.height || nc>=board.width) continue
                val a=board[r,c]; val z=board[nr,nc]
                if(a.kind!=Kind.CANDY || z.kind!=Kind.CANDY || !a.movable || !z.movable ||
                   a.color<0 || z.color<0 || a.color==z.color ||
                   a.confidence<minimumConfidence || z.confidence<minimumConfidence) continue
                val swapped=board.rows.map { it.toMutableList() }
                swapped[r][c]=z; swapped[nr][nc]=a
                val next=Board(swapped)
                val fresh=matchCells(next)-before
                val fish=fishSquares(next)-fishBefore
                val touchesSwap=(fresh+fish).any { it==(r to c) || it==(nr to nc) }
                if(!touchesSwap || (fresh.isEmpty() && fish.isEmpty())) continue
                out.add(Move(r,c,nr,nc,fresh.size,fish.isNotEmpty(),fresh.size*10+if(fish.isNotEmpty()) 25 else 0))
            }
        }
        return Result(out.sortedByDescending { it.score },if(out.isEmpty()) "검증된 일반 매치 없음" else null)
    }
}
