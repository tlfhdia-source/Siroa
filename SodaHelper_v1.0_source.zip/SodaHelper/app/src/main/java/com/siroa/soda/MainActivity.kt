package com.siroa.soda

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.EditText
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView

class MainActivity : Activity() {
 private val requestCode = 1234
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val scroll = ScrollView(this)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,64,32,32) }
  root.addView(TextView(this).apply { text = "Soda Helper v1.0\n게임판 진단 + 이동 검증 엔진 연결\n\n세로 화면의 게임판을 기준으로 분석합니다.\n화면 분류 결과를 판단 엔진에 전달합니다. 화면 위 격자 중심점을 표시해 좌표를 진단합니다. 이동 추천은 검증 전까지 중지합니다."; textSize=18f })
  val prefs = getSharedPreferences("grid", MODE_PRIVATE)
  val fields = listOf("rows" to "행 수", "cols" to "열 수", "left" to "왼쪽 경계 (0~1)", "top" to "위 경계 (0~1)", "right" to "오른쪽 경계 (0~1)", "bottom" to "아래 경계 (0~1)")
  val inputs = fields.map { (key, label) ->
   val edit = EditText(this).apply {
    hint = label
    setSingleLine(true)
    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    setText(if (key == "rows" || key == "cols") prefs.getInt(key,9).toString() else prefs.getFloat(key, when(key) {"left" -> .022f; "top" -> .253f; "right" -> .978f; else -> .708f}).toString())
   }
   root.addView(edit); key to edit
  }
  root.addView(Button(this).apply { text="게임판 설정 저장"; setOnClickListener {
   val values = inputs.associate { (key, edit) -> key to (edit.text.toString().toFloatOrNull() ?: Float.NaN) }
   val l=values["left"]!!; val t=values["top"]!!; val r=values["right"]!!; val b=values["bottom"]!!
   if(values.values.any { !it.isFinite() } || values["rows"]!! !in 3f..15f || values["cols"]!! !in 3f..15f || l !in 0f..1f || t !in 0f..1f || r !in 0f..1f || b !in 0f..1f || l>=r || t>=b) {
    android.widget.Toast.makeText(this@MainActivity,"설정값을 확인하세요",android.widget.Toast.LENGTH_LONG).show()
   } else {
    prefs.edit().putInt("rows",values["rows"]!!.toInt()).putInt("cols",values["cols"]!!.toInt()).putFloat("left",l).putFloat("top",t).putFloat("right",r).putFloat("bottom",b).apply()
    android.widget.Toast.makeText(this@MainActivity,"저장됨: 화면 분석을 다시 시작하세요",android.widget.Toast.LENGTH_LONG).show()
   }
  } })
  root.addView(Button(this).apply { text="좌표를 v1.0 기본값으로 초기화"; setOnClickListener {
   prefs.edit().putInt("rows",9).putInt("cols",9).putFloat("left",.022f).putFloat("top",.253f).putFloat("right",.978f).putFloat("bottom",.708f).apply()
   inputs.forEach { (key, edit) -> edit.setText(when(key) { "rows","cols" -> "9"; "left" -> "0.022"; "top" -> "0.253"; "right" -> "0.978"; else -> "0.708" }) }
   android.widget.Toast.makeText(this@MainActivity,"기본 좌표 적용됨. 분석을 다시 시작하세요",android.widget.Toast.LENGTH_LONG).show()
  } })
  root.addView(Button(this).apply { text="플로팅 창 권한 허용"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  root.addView(Button(this).apply { text="화면 분석 시작"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return@setOnClickListener }
   val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
  } })
  root.addView(Button(this).apply { text="분석 종료"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)) } })
  root.addView(TextView(this).apply { text = "안내: 격자 점이 실제 캔디의 중앙과 일치하는지 확인하세요. 맞지 않으면 경계 비율을 수정하고 분석을 다시 시작하세요. 게임판 모양이 불규칙한 경우에도 행/열 사각 격자는 진단용일 뿐입니다."; textSize=15f })
  scroll.addView(root)
  setContentView(scroll)
 }
 @Deprecated("Deprecated in Android")
 override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==this.requestCode && resultCode==RESULT_OK && data!=null) {
   startForegroundService(Intent(this,CaptureService::class.java).putExtra("resultCode",resultCode).putExtra("data",data))
  }
 }
}
