package com.siroa.soda

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 private val requestCode = 1234
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,64,32,32) }
  root.addView(TextView(this).apply { text = "Soda Helper v0.1\n게임 화면 분석 실험판\n\n게임판을 화면 중앙에 놓고 분석을 시작하세요.\n캔디 색상 인식은 실험 단계이며 특수 블록은 지원하지 않습니다."; textSize=18f })
  root.addView(Button(this).apply { text="플로팅 창 권한 허용"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  root.addView(Button(this).apply { text="화면 분석 시작"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return@setOnClickListener }
   val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
  } })
  root.addView(Button(this).apply { text="분석 종료"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)) } })
  setContentView(root)
 }
 @Deprecated("Deprecated in Android")
 override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==this.requestCode && resultCode==RESULT_OK && data!=null) {
   startForegroundService(Intent(this,CaptureService::class.java).putExtra("resultCode",resultCode).putExtra("data",data))
  }
 }
}
