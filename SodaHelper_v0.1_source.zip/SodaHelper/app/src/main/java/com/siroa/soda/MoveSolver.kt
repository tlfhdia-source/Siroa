package com.siroa.soda

/** Prototype only: assumes a regular grid of flat-colored candies. */
object MoveSolver {
 data class Move(val row:Int,val col:Int,val toRow:Int,val toCol:Int,val score:Int)
 fun best(board:Array<IntArray>):Move? {
  val h=board.size; if(h==0)return null; val w=board[0].size
  var best:Move?=null
  for(r in 0 until h) for(c in 0 until w) for((dr,dc) in listOf(0 to 1,1 to 0)) {
   val nr=r+dr; val nc=c+dc; if(nr>=h||nc>=w||board[r][c]<0||board[nr][nc]<0||board[r][c]==board[nr][nc])continue
   val copy=Array(h){board[it].clone()}; val temp=copy[r][c];copy[r][c]=copy[nr][nc];copy[nr][nc]=temp
   val matched=HashSet<Pair<Int,Int>>()
   for(y in 0 until h) for(x in 0 until w) {
    val v=copy[y][x];if(v<0)continue
    if(x+2<w && copy[y][x+1]==v && copy[y][x+2]==v) { var k=x;while(k<w&&copy[y][k]==v){matched.add(y to k);k++} }
    if(y+2<h && copy[y+1][x]==v && copy[y+2][x]==v) { var k=y;while(k<h&&copy[k][x]==v){matched.add(k to x);k++} }
   }
   val score=matched.size
   if(score>=3 && (best==null||score>best.score))best=Move(r,c,nr,nc,score)
  }
  return best
 }
}
